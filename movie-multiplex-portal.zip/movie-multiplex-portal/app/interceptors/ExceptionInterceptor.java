package interceptors;

import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Result;
import scala.reflect.internal.Trees;

import java.util.concurrent.CompletionStage;

public class ExceptionInterceptor extends Action.Simple {
    @Override
    public CompletionStage<Result> call(Http.Request req) {

        try {
            CompletionStage<Result> result = delegate.call(req);

            return result;
        }
        catch (Throwable e){
            throw new RuntimeException(e);
        }
    }
}
