package entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AllotMovieEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private int movieId;

    @Override
    public String toString() {
        return "AllotMovieEntity{" +
                "id=" + id +
                ", movieId=" + movieId +
                ", movieName='" + movieName + '\'' +
                ", multiplexId=" + multiplexId +
                ", multiplexName='" + multiplexName + '\'' +
                ", screenNo=" + screenNo +
                '}';
    }

    private String movieName;
    private int multiplexId;
    private String multiplexName;
    private int screenNo;

    public AllotMovieEntity() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public int getMultiplexId() {
        return multiplexId;
    }

    public void setMultiplexId(int multiplexId) {
        this.multiplexId = multiplexId;
    }

    public String getMultiplexName() {
        return multiplexName;
    }

    public void setMultiplexName(String multiplexName) {
        this.multiplexName = multiplexName;
    }

    public int getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(int screenNo) {
        this.screenNo = screenNo;
    }

    public AllotMovieEntity(int movieId, String movieName, int multiplexId, String multiplexName, int screenNo) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.multiplexId = multiplexId;
        this.multiplexName = multiplexName;
        this.screenNo = screenNo;
    }
}
