package entities;

import play.data.validation.Constraints;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MultiplexEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String multiplexName;
    private String address;
    private Integer noOfScreens;

    public MultiplexEntity() {}

    @Override
    public String toString() {
        return "Multiplex{" +
                "id=" + id +
                ", multiplexNmae='" + multiplexName + '\'' +
                ", address='" + address + '\'' +
                ", noOfScreens=" + noOfScreens +
                '}';
    }

    public MultiplexEntity(String multiplexName, String address, Integer noOfScreens) {
        this.multiplexName = multiplexName;
        this.address = address;
        this.noOfScreens = noOfScreens;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMultiplexName() {
        return multiplexName;
    }

    public void setMultiplexName(String multiplexName) {
        this.multiplexName = multiplexName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getNoOfScreens() {
        return noOfScreens;
    }

    public void setNoOfScreens(Integer noOfScreens) {
        this.noOfScreens = noOfScreens;
    }
}
