package service;

import entities.MovieEntity;
import model.Movie;
import repository.MovieRepository;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Singleton
public class MovieService {

    @Inject
    private MovieRepository movieRepository;

    public void addMovie(Movie movieModel){
      // model -> entity
        //String name, String category, String producer, String director, String releaseDate
        MovieEntity movie = new MovieEntity(movieModel.name,movieModel.category,movieModel.producer,movieModel.director,movieModel.releaseDate);
        this.movieRepository.insert(movie);
    }

    public void updateMovie(Movie movieModel,Integer movieId){
        MovieEntity movie = new MovieEntity(movieModel.name,movieModel.category,movieModel.producer,movieModel.director,movieModel.releaseDate);
        movie.setId(movieId);
        this.movieRepository.update(movie);
    }

    // to get all the list of movies
    public List<Movie> getMovieList(){
        List<Movie> movies = new ArrayList<>();

        List<MovieEntity> movieEntityList = this.movieRepository.list();

        // Integer id, String name, String category, String producer, String director, String releaseDate
        movies = movieEntityList.stream()
                .map(movie -> new Movie(movie.getId(),movie.getName(),movie.getCategory(),movie.getProducer(),movie.getDirector(),movie.getReleaseDate()))
                .collect(Collectors.toList());

        return movies;
    }
    // to find a movie by Id
    public Movie findMovieById(Integer movieId){
        MovieEntity movie = this.movieRepository.findById(movieId);
        if(movie!=null) {
            return (new Movie(movie.getId(), movie.getName(), movie.getCategory(), movie.getProducer(), movie.getDirector(), movie.getReleaseDate()));
        }
        else {
            return null;
        }
    }
    // to delete a movie by Id
    public void deleteMovie(Integer movieId){
        this.movieRepository.delete(movieId);
    }
}
