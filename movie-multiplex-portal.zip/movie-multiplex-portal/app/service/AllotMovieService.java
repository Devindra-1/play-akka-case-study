package service;

import entities.AllotMovieEntity;
import entities.MovieEntity;
import model.AllotMovie;
import model.Movie;
import repository.AllotMovieRepository;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AllotMovieService {

    @Inject
    AllotMovieRepository allotMovieRepository;

    public List<AllotMovie> getAlloMovieList(){
        List<AllotMovie> allotMovies = new ArrayList<>();

        List<AllotMovieEntity> allotMovieEntityList = this.allotMovieRepository.list();

        allotMovies = allotMovieEntityList.stream()
                .map(allotMovie -> new AllotMovie(allotMovie.getId(),allotMovie.getMovieId(),allotMovie.getMovieName(),allotMovie.getMultiplexId(),allotMovie.getMultiplexName(),allotMovie.getScreenNo()))
                .collect(Collectors.toList());

        return allotMovies;
    }

    // add alloted movie
    public void addAllotMovie(AllotMovie allotMovieModel){
        // model -> entity
        //String name, String category, String producer, String director, String releaseDate
        AllotMovieEntity allotMovie = new AllotMovieEntity(allotMovieModel.movieId,allotMovieModel.movieName,allotMovieModel.multiplexId,allotMovieModel.multiplexName,allotMovieModel.screenNo);
        this.allotMovieRepository.insert(allotMovie);
    }
}
