package service;


import entities.MultiplexEntity;
import model.Multiplex;
import repository.MultiplexRepository;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Singleton
public class MultiplexService {

    @Inject
    private MultiplexRepository multiplexRepository;

    public void addMultiplex(Multiplex multiplexModel){
      // model -> entity
        //String name, String category, String producer, String director, String releaseDate
        MultiplexEntity multiplex = new MultiplexEntity(multiplexModel.multiplexName,multiplexModel.address,multiplexModel.noOfScreens);
        this.multiplexRepository.insert(multiplex);
    }

    public void updateMultiplex(Multiplex multiplexModel,Integer multiplexId){
        MultiplexEntity multiplex = new MultiplexEntity(multiplexModel.multiplexName,multiplexModel.address,multiplexModel.noOfScreens);
        multiplex.setId(multiplexId);
        this.multiplexRepository.update(multiplex);
    }

    // to get all the list of multiplexs
    public List<Multiplex> getMultiplexList(){
        List<Multiplex> multiplexs = new ArrayList<>();

        List<MultiplexEntity> multiplexEntityList = this.multiplexRepository.list();

        // Integer id, String name, String category, String producer, String director, String releaseDate
        multiplexs = multiplexEntityList.stream()
                .map(multiplex -> new Multiplex(multiplex.getId(),multiplex.getMultiplexName(),multiplex.getAddress(),multiplex.getNoOfScreens()))
                .collect(Collectors.toList());

        return multiplexs;
    }
    // to find a multiplex by Id
    public Multiplex findMultiplexById(Integer multiplexId){
        MultiplexEntity multiplex = this.multiplexRepository.findById(multiplexId);
        if(multiplex!=null) {
            return (new Multiplex(multiplex.getId(), multiplex.getMultiplexName(), multiplex.getAddress(), multiplex.getNoOfScreens()));
        }
        else {
            return null;
        }
    }
    // to delete a multiplex by Id
    public void deleteMultiplex(Integer multiplexId){
        this.multiplexRepository.delete(multiplexId);
    }
}
