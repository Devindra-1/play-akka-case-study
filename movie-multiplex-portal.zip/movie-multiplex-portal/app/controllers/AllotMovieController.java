package controllers;

import model.AllotMovie;
import model.Movie;
import model.Multiplex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.data.Form;
import play.data.FormFactory;
import play.i18n.MessagesApi;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import service.AllotMovieService;
import service.MovieService;
import service.MultiplexService;

import javax.inject.Inject;
import java.util.List;

public class AllotMovieController extends Controller {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Inject
    private AllotMovieService allotMovieService;
    @Inject
    FormFactory formFactory;
    @Inject
    MessagesApi messagesApi;
    @Inject
    private MovieService movieService;
    @Inject
    private MultiplexService multiplexService;
    // to show list of alloted movies to multiplex and screens
    public Result allotMovie(){
        List<AllotMovie> allotMovies = this.allotMovieService.getAlloMovieList();
        return ok(views.html.allotMovie.index.render(allotMovies));
    }

    // to allot a movie to a multiplex
    public Result entry(Http.Request request){
        Form<AllotMovie> allotMovieForm = formFactory.form(AllotMovie.class);
        List<Movie> movies = this.movieService.getMovieList();
        List<Multiplex> multiples = this.multiplexService.getMultiplexList();

        return ok(views.html.allotMovie.create.render(allotMovieForm,movies,multiples,request, messagesApi.preferred(request)));
    }
    public Result save(Http.Request request){
        Form<AllotMovie> allotMovieForm = formFactory.form(AllotMovie.class).bindFromRequest(request);
        if(allotMovieForm.hasErrors()){
            request.flash().adding("failed","Constraints Not Satisfied!!!");
            logger.error("error {}," + allotMovieForm.errors());
            List<Movie> movies = this.movieService.getMovieList();
            List<Multiplex> multiples = this.multiplexService.getMultiplexList();
            return badRequest(views.html.allotMovie.create.render(allotMovieForm,movies,multiples,request,messagesApi.preferred(request)));
        }

        AllotMovie allotMovie = allotMovieForm.get();
        this.allotMovieService.addAllotMovie(allotMovie);
        return redirect(routes.AllotMovieController.allotMovie());
    }

//    public Result screenSelect(){
//        return redirect(routes.AllotMovieController.allotMovie());
//    }
}
