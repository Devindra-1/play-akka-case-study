package controllers;

import interceptors.ExceptionInterceptor;
import model.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.data.Form;
import play.data.FormFactory;
import play.i18n.MessagesApi;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.With;
import repository.MovieRepository;
import service.MovieService;

import javax.inject.Inject;
import java.util.List;

//@With(ExceptionInterceptor.class)
public class MovieController extends Controller {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Inject
    FormFactory formFactory;
    @Inject
    MessagesApi messagesApi;

    @Inject
    MovieService movieService;

    // to show list of movies
    public Result movie(){
        List<Movie> movies = this.movieService.getMovieList();
        return ok(views.html.movie.index.render(movies));
    }

    // to add a new movie entry
    public Result entry(Http.Request request){
        Form<Movie> movieForm = formFactory.form(Movie.class);
        return ok(views.html.movie.create.render(movieForm,request, messagesApi.preferred(request)));
    }
    public Result save(Http.Request request){

        Form<Movie> movieForm = formFactory.form(Movie.class).bindFromRequest(request);

        if(movieForm.hasErrors()){
            request.flash().adding("failed","Constraints Not Satisfied!!!");
            logger.error("error {}," + movieForm.errors());
            return badRequest(views.html.movie.create.render(movieForm,request,messagesApi.preferred(request)));
        }

        Movie movie = movieForm.get();
        this.movieService.addMovie(movie);
        //request.flash().adding("success","Operation Successfully Completed");
        return redirect(routes.MovieController.movie());
    }

    // to delete a movie
    public Result delete(Integer movieId){
        this.movieService.deleteMovie(movieId);
        return redirect(routes.MovieController.movie());
    }

    // to edit and update a movie
    public Result edit(Integer movieId,Http.Request request){

        Movie movie = this.movieService.findMovieById(movieId);
        if(movie==null){
            return notFound("Movie Not Found!!!");
        }
        Form<Movie> movieForm = formFactory.form(Movie.class).fill(movie);
        return ok(views.html.movie.edit.render(movieForm,movieId,request, messagesApi.preferred(request)));
    }
    public Result update(Integer movieId,Http.Request request){


        Form<Movie> movieForm = formFactory.form(Movie.class).bindFromRequest(request);

        if(movieForm.hasErrors()){
            request.flash().adding("failed","Constraints Not Satisfied!!!");
            logger.error("error {}," + movieForm.errors());
            return badRequest(views.html.movie.create.render(movieForm,request,messagesApi.preferred(request)));
        }

        Movie movie = movieForm.get();
        this.movieService.updateMovie(movie,movieId);

        return redirect(routes.MovieController.movie());
    }
}
