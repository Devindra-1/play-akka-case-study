package controllers;

import model.Multiplex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.data.Form;
import play.data.FormFactory;
import play.i18n.MessagesApi;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import service.MultiplexService;

import javax.inject.Inject;
import java.util.List;

public class MultiplexController extends Controller {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Inject
    FormFactory formFactory;
    @Inject
    MessagesApi messagesApi;

    @Inject
    MultiplexService multiplexService;

    // to show list of multiplexs
    public Result multiplex(){
        List<Multiplex> multiplexs = this.multiplexService.getMultiplexList();
        return ok(views.html.multiplex.index.render(multiplexs));
    }

    // to add a new multiplex entry
    public Result entry(Http.Request request){
        Form<Multiplex> multiplexForm = formFactory.form(Multiplex.class);
        return ok(views.html.multiplex.create.render(multiplexForm,request, messagesApi.preferred(request)));
    }
    public Result save(Http.Request request){

        Form<Multiplex> multiplexForm = formFactory.form(Multiplex.class).bindFromRequest(request);

        if(multiplexForm.hasErrors()){
            request.flash().adding("failed","Constraints Not Satisfied!!!");
            logger.error("error {}," + multiplexForm.errors());
            return badRequest(views.html.multiplex.create.render(multiplexForm,request,messagesApi.preferred(request)));
        }

        Multiplex multiplex = multiplexForm.get();
        this.multiplexService.addMultiplex(multiplex);
        //request.flash().adding("success","Operation Successfully Completed");
        return redirect(routes.MultiplexController.multiplex());
    }

    // to delete a movie
    public Result delete(Integer multiplexId){
        this.multiplexService.deleteMultiplex(multiplexId);
        return redirect(routes.MultiplexController.multiplex());
    }

    // to edit and update a multiplex
    public Result edit(Integer multiplexId,Http.Request request){

        Multiplex multiplex = this.multiplexService.findMultiplexById(multiplexId);
        if(multiplex==null){
            return notFound("Movie Not Found!!!");
        }
        Form<Multiplex> multiplexForm = formFactory.form(Multiplex.class).fill(multiplex);
        return ok(views.html.multiplex.edit.render(multiplexForm,multiplexId,request, messagesApi.preferred(request)));
    }
    public Result update(Integer multiplexId,Http.Request request){


        Form<Multiplex> multiplexForm = formFactory.form(Multiplex.class).bindFromRequest(request);

        if(multiplexForm.hasErrors()){
            request.flash().adding("failed","Constraints Not Satisfied!!!");
            logger.error("error {}," + multiplexForm.errors());
            return badRequest(views.html.multiplex.create.render(multiplexForm,request,messagesApi.preferred(request)));
        }

        Multiplex multiplex = multiplexForm.get();
        this.multiplexService.updateMultiplex(multiplex,multiplexId);

        return redirect(routes.MultiplexController.multiplex());
    }
}
