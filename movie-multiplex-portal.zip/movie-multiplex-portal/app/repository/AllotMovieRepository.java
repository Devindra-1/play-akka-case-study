package repository;

import entities.AllotMovieEntity;
import entities.MovieEntity;
import play.db.jpa.JPAApi;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.function.Function;

public class AllotMovieRepository {

    @Inject
    private JPAApi jpaApi;

    private <T>   T wrap(Function<EntityManager,T> function){
        return this.jpaApi.withTransaction(function);
    }

    public List<AllotMovieEntity> list(){
        return this.wrap(entityManager -> {
            List<AllotMovieEntity> allotMovies = entityManager.createQuery("select m from AllotMovieEntity m", AllotMovieEntity.class).getResultList();
            return allotMovies;
        });
    }

    @Transactional
    public AllotMovieEntity insert(AllotMovieEntity allotMovieEntity){
        return this.wrap(entityManager -> {
            entityManager.persist(allotMovieEntity);
            return allotMovieEntity;
        });

    }

}
