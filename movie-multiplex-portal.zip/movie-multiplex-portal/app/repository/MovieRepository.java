package repository;

import entities.MovieEntity;
import model.Movie;
import play.db.jpa.JPAApi;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

public class MovieRepository {

    @Inject
    private JPAApi jpaApi;

    @Transactional
    public MovieEntity insert(MovieEntity movieEntity){
        this.jpaApi.withTransaction(entityManager -> {
            entityManager.persist(movieEntity);
        });
        return movieEntity;
    }

    private <T>   T wrap(Function<EntityManager,T> function){
        return this.jpaApi.withTransaction(function);
    }

    public MovieEntity update(MovieEntity movieEntity){
        this.jpaApi.withTransaction(entityManager -> {
            entityManager.merge(movieEntity);
        });
        return movieEntity;
    }

    public List<MovieEntity> list(){
        return this.wrap(entityManager -> {
            List<MovieEntity> movies = entityManager.createQuery("select m from MovieEntity m", MovieEntity.class).getResultList();
                    return movies;
        });
    }

    public MovieEntity findById(Integer movieId){
        return this.wrap(entityManager -> {
            return entityManager.find(MovieEntity.class,movieId);
        });
    }

    public void delete(Integer movieId){

        this.wrap(entityManager -> {
            MovieEntity movieEntity = entityManager.find(MovieEntity.class,movieId);
            if(movieEntity==null) {
                return false;
            }
            else {
                entityManager.remove(movieEntity);
                return true;
            }

        });
    }
}
