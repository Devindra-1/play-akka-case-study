package repository;

import entities.MultiplexEntity;
import play.db.jpa.JPAApi;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.function.Function;

public class MultiplexRepository {

    @Inject
   private JPAApi jpaApi;

    @Transactional
    public MultiplexEntity insert(MultiplexEntity multiplexEntity){
        this.jpaApi.withTransaction(entityManager -> {
            entityManager.persist(multiplexEntity);
        });
        return multiplexEntity;
    }

    private <T>   T wrap(Function<EntityManager,T> function){
        return this.jpaApi.withTransaction(function);
    }

    public MultiplexEntity update(MultiplexEntity multiplexEntity){
        this.jpaApi.withTransaction(entityManager -> {
            entityManager.merge(multiplexEntity);
        });
        return multiplexEntity;
    }

    public List<MultiplexEntity> list(){
        return this.wrap(entityManager -> {
            List<MultiplexEntity> multiplexs = entityManager.createQuery("select m from MultiplexEntity m", MultiplexEntity.class).getResultList();
                    return multiplexs;
        });
    }

    public MultiplexEntity findById(Integer multiplexId){
        return this.wrap(entityManager -> {
            return entityManager.find(MultiplexEntity.class,multiplexId);
        });
    }

    public void delete(Integer multiplexId){

        this.wrap(entityManager -> {
            MultiplexEntity multiplexEntity = entityManager.find(MultiplexEntity.class,multiplexId);
            if(multiplexEntity==null) {
                return false;
            }
            else {
                entityManager.remove(multiplexEntity);
                return true;
            }
        });
    }
}
