package model;

import play.data.validation.Constraints;

public class Movie {
    //@Constraints.Required(message = "Id is required!!!")
    public Integer id;
    @Constraints.Required(message = "Name is required!!!")
    public String name;
    @Constraints.Required(message = "Category is required!!!")
    public String category;
    @Constraints.Required(message = "Producer is required!!!")
    public String producer;
    @Constraints.Required(message = "Director is required!!!")
    public String director;
    @Constraints.Required(message = "Release Date is required!!!")
    public String releaseDate;

    public Movie() {}

    @Override
    public String toString() {
        return "Movie{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", category='" + category + '\'' +
                ", producer='" + producer + '\'' +
                ", director='" + director + '\'' +
                ", releaseDate=" + releaseDate +
                '}';
    }

    public Movie(Integer id, String name, String category, String producer, String director, String releaseDate) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.producer = producer;
        this.director = director;
        this.releaseDate = releaseDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProducer() {
        return producer;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }
}
