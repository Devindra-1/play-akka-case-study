package model;

import play.data.validation.Constraints;

public class Multiplex {
   public Integer id;
    @Constraints.Required(message = "Name is required!!!")
    public String multiplexName;
    @Constraints.Required(message = "Address is required!!!")
    public String address;
    @Constraints.Required(message = "No of Screens required!!!")
    public Integer noOfScreens;

    public Multiplex() {}

    @Override
    public String toString() {
        return "Multiplex{" +
                "id=" + id +
                ", multiplexNmae='" + multiplexName + '\'' +
                ", address='" + address + '\'' +
                ", noOfScreens=" + noOfScreens +
                '}';
    }

    public Multiplex(Integer id, String multiplexName, String address, Integer noOfScreens) {
        this.id = id;
        this.multiplexName = multiplexName;
        this.address = address;
        this.noOfScreens = noOfScreens;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMultiplexName() {
        return multiplexName;
    }

    public void setMultiplexName(String multiplexName) {
        this.multiplexName = multiplexName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getNoOfScreens() {
        return noOfScreens;
    }

    public void setNoOfScreens(Integer noOfScreens) {
        this.noOfScreens = noOfScreens;
    }
}
