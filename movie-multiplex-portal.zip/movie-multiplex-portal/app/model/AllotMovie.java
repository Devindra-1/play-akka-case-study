package model;

import play.data.validation.Constraints;

public class AllotMovie {
    public int id;
    public int movieId;
    @Constraints.Required(message = "Select Movie!!!")
    public String movieName;
    public int multiplexId;
    @Constraints.Required(message = "Select Multiplex!!!")
    public String multiplexName;
    @Constraints.Required(message = "Select screen !!!")
    public int screenNo;
    @Override
    public String toString() {
        return "AllotMovie{" +
                "id=" + id +
                ", movieId=" + movieId +
                ", movieName='" + movieName + '\'' +
                ", multiplexId=" + multiplexId +
                ", multiplexName='" + multiplexName + '\'' +
                ", screenNo=" + screenNo +
                '}';
    }

    public AllotMovie() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public int getMultiplexId() {
        return multiplexId;
    }

    public void setMultiplexId(int multiplexId) {
        this.multiplexId = multiplexId;
    }

    public String getMultiplexName() {
        return multiplexName;
    }

    public void setMultiplexName(String multiplexName) {
        this.multiplexName = multiplexName;
    }

    public int getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(int screenNo) {
        this.screenNo = screenNo;
    }

    public AllotMovie(int id, int movieId, @Constraints.Required(message = "Select Movie!!!") String movieName, int multiplexId, @Constraints.Required(message = "Select Multiplex!!!") String multiplexName, @Constraints.Required(message = "screen no is required!!!") int screenNo) {
        this.id = id;
        this.movieId = movieId;
        this.movieName = movieName;
        this.multiplexId = multiplexId;
        this.multiplexName = multiplexName;
        this.screenNo = screenNo;
    }
}
